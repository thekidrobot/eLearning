<html>
<head>
	<title>reporte de descargas</title>
<?php if (@$sExport == "" || @$sExport == "html") { ?>
<link href="phprptcss/reporte1_victor.css" rel="stylesheet" type="text/css">
<?php } ?>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="generator" content="PHP Report Maker v3.0.0.1" />
</head>
<body>
<?php if (@$sExport == "") { ?>
<script type="text/javascript">
var EW_REPORT_IMAGES_FOLDER = "phprptimages";
</script>
<script src="phprptjs/x.js" type="text/javascript"></script>
<div class="ewLayout">
	<!-- header (begin) --><!-- *** Note: Only licensed users are allowed to change the logo *** -->
	<div class="ewHeaderRow"><img src="phprptmkrlogo3.png" alt="" border="0" /></div>
	<!-- header (end) -->
	<!-- content (begin) -->
	<!-- navigation -->
	<table cellspacing="0" class="ewContentTable">
		<tr>	
			<td class="ewMenuColumn">
<?php include "phprptinc/menu.php"; ?>
			</td>
			<td class="ewContentColumn">
<?php } ?>
